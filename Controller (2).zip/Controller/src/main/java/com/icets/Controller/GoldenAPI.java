package com.icets.Controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class GoldenAPI {

    static private final String DB_DIR = "C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Data"; // directory with production databases
    static private final String USERS_DIR = "C:\\data"; // directory with user names as folders
    static private final String TEMP_DIR = "C:\\backup"; // MEB temporary directory

    // returns a list of existing user accounts
    static public ArrayList<String> getUserNames () {
        File usersDir = new File (USERS_DIR);
        ArrayList<String> names = new ArrayList();

        for (File file : usersDir.listFiles())
            if (file.isDirectory())
                names.add(file.getName());
        return names;
    }

    // returns a list of names of databases
    static public ArrayList<String> getDBNames () {
        File dataDir = new File (DB_DIR);
        ArrayList<String> dbNames = new ArrayList();

        for (File file : dataDir.listFiles()) {
            if (file.isDirectory() &&
                    !file.getName().equals("#innodb_temp") &&
                    !file.getName().equals("mysql") &&
                    !file.getName().equals("performance_schema") &&
                    !file.getName().equals("sys"))
            {
                dbNames.add(file.getName());
            }
        }
        return dbNames;
    }

    // returns a list of databases that the user has access to
    static public ArrayList<String> showAccess (String userName) {
        final String USER_DIR = USERS_DIR + "\\" + userName;
        File userDir = new File (USER_DIR);
        ArrayList<String> names = new ArrayList();

        // if user does not exist then return an empty collection
        if (!userDir.isDirectory()) return names;

        for (File file : userDir.listFiles())
            if (file.isDirectory())
                names.add(file.getName());
        return names;
    }

    // creates a new user account
    // returns true if success
    // TODO: ???
    static public boolean createUser (String userName){
        return new File(USERS_DIR + "\\" + userName).mkdir();
    }

    // deletes a user account
    // returns true if success
    static public boolean deleteUser (String userName) {
        final String USER_DIR = USERS_DIR + "\\" + userName;

        try {
            File folder = new File(USER_DIR);
            delete(folder);
        }
        catch (Exception E) {return false;}

        System.out.println("\nUser account " + userName + " deleted successfully.\n");
        return true;
    }

    // retrieves a database from MySQL Server and copies it to USERS_DIR\ userName\ dbName folder
    // returns true if success
    // TODO: interpret error code mysqlbackup returns and return true/false
    // TODO: if user does not exist then return false
    static public boolean getGC (String userName, String dbName) {

        final String TARGET_DIR = USERS_DIR + "\\" + userName; // directory where GC is to be created
        // used for mysqlbackup command line options
        final String BACKUP_IMAGE = "--backup-image=" + TEMP_DIR + "\\backup.mbi";
        final String INCLUDE_TABLES = "--include-tables=\"" + dbName + "\"";
        final String BACKUP_TEMP_DIR = "--backup-dir=" + TEMP_DIR + "\\tempb";
        final String RESTORE_TEMP_DIR = "--backup-dir=" + TEMP_DIR + "\\tempr";
        final String DATA_DIR = "--datadir=" + TARGET_DIR;

        // used for command line
        // backupCommand will most likely have to use ssh to ask the production server to backup the server
        // using MEB and send it to USERS_DIR on this (golden) server
        String[] backupCommand = {"mysqlbackup", "--user=root", "--password=Root", BACKUP_TEMP_DIR,
                BACKUP_IMAGE, "--compress", INCLUDE_TABLES, "backup-to-image"};
        String[] restoreCommand = {"mysqlbackup", RESTORE_TEMP_DIR, DATA_DIR,
                "--uncompress", BACKUP_IMAGE, "copy-back-and-apply-log"};

        // run backup
        try {
            ProcessBuilder builder = new ProcessBuilder(backupCommand);
            builder.redirectErrorStream(true);
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        }
        catch (Exception E){return false;}

        // restore to target folder
        try {
            ProcessBuilder builder = new ProcessBuilder(restoreCommand);
            builder.redirectErrorStream(true);
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        }
        catch (Exception E) {return false;}

        // delete temporary files
        try {
            File folder = new File(TEMP_DIR);
            delete(folder);
        }
        catch (Exception E) {return false;}
        System.out.println("\nTemporary files deleted successfully.\n");

        // return
        return true;
    }

    // deletes the specified folder and all its contents
    private static void delete(File folder) throws IOException {

        for (File childFile : folder.listFiles()) {

            if (childFile.isDirectory()) {
                delete(childFile);
            } else {
                if (!childFile.delete()) {
                    throw new IOException();
                }
            }
        }

        if (!folder.delete()) {
            throw new IOException();
        }
    }
}
