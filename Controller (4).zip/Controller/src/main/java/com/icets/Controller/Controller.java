package com.icets.Controller;

import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;

@org.springframework.stereotype.Controller
public class Controller {

    GoldenAPI session;

    @RequestMapping("/login")
    public String login (@RequestParam("user") String user, @RequestParam("pass") String pass) {
        session = new GoldenAPI();
        return "redirect:" + session.login(user, pass);
    }

    @RequestMapping("/getUserNames")
    @ResponseBody
    public ArrayList<String> getUserNames () throws Exception {
        return session.getUserNames();
    }

    @RequestMapping("/getDBNames")
    @ResponseBody
    public ArrayList<String> getDBNames () {
        return session.getDBNames();
    }

    @RequestMapping("/showAccess")
    @ResponseBody
    public ArrayList<String> showAccess (@RequestParam("user") String user) {
        return session.showAccess(user);
    }

    @RequestMapping("/mount")
    @ResponseBody
    public boolean mount (@RequestParam("dbname") String dbName) {
        return session.mount(dbName);
    }

    @RequestMapping("/save")
    @ResponseBody
    public boolean save (@RequestParam("dbname") String dbName) {
        return session.save(dbName);
    }

    @RequestMapping("/share")
    @ResponseBody
    public boolean share (@RequestParam("user") String user, @RequestParam("dbname") String dbName) {
        return session.share(user, dbName);
    }

    @RequestMapping("/getGC")
    @ResponseBody
    public boolean getGC (@RequestParam("user") String user, @RequestParam("db") String db) {
        return session.getGC(user, db);
    }

    @RequestMapping("/createUser")
    @ResponseBody
    public boolean createUser (@RequestParam("user") String user, @RequestParam("pass") String pass) {
        return session.createUser(user, pass);
    }

    @RequestMapping("/deleteUser")
    @ResponseBody
    public boolean deleteUser (@RequestParam("user") String user) {
        return session.deleteUser(user);
    }
}
