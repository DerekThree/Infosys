package com.icets.Controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class GoldenAPI {

    // constants for file structure
    private final String DB_DIR = "C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Data"; // directory with production databases
    private final String USERS_DIR = "C:\\data"; // directory with user names as folders
    private final String TEMP_DIR = "C:\\backup"; // MEB temporary directory
    private final String LOGIN_PAGE = "Login.html";
    private final String ADMIN_PAGE = "Admin.html";
    private final String USER_PAGE = "User.html;";

    // variables for connection with MySQL Server
    private String username; // MySQL Server username
    private String password; // MySQLServer password
    private Statement stmt; // statement for SQL queries
    private Connection con;

    // returns the name of the admin page or user site, based on what type of account user has
    // returns the name of the login page if login was incorrect
    String login (String user, String pass) {

        // login to MySQL Server
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/admin", user, pass);
            stmt = con.createStatement();
        }
        catch (Exception e) {return LOGIN_PAGE;}

        // if success then store credentials
        username = user;
        password = pass;

        // check if the user has admin privileges
        // by checking if the username is in the admin.names table
        try {
             ResultSet rs = stmt.executeQuery("SELECT * FROM names WHERE id=\'" + user + "\'");
            if (rs.next()) return ADMIN_PAGE; // if the name showed up at least once
            else return USER_PAGE;
        }
        catch (Exception e) {System.out.println("Exception");return LOGIN_PAGE;}
    }

    // mounts a db as the current db by running 'USE dbName" SQL query
    // returns true if success
    // TODO: ???
    boolean mount (String dbName) {
        return false;
    }

    // saves the current db under given name
    // TODO: this method will copy the current db (using sqldump?) and give the copy newName,
    // TODO: current db is the one set using 'USE dbName" SQL query
    boolean save (String newName) {
        return false;
    }

    // gives a user access to a db by creating a copy of that db (using sqldump?),
    // the copy has username and version prepended to its name
    // returns true if success
    // TODO: needs to create a copy of the db with user and version prepended to its name
    boolean share (String user, String dbName) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/admin", username, password);
            stmt.execute("GRANT ALL PRIVILEGES ON " + dbName + ".* TO \'" + user + "\';");

        }
        catch (Exception e) {System.out.println("exception");return false;}

        return true;
    }

    // returns a list of existing user accounts
    // by running a query and returning filtered results
    ArrayList<String> getUserNames () {
        ArrayList<String> userNames = new ArrayList<String>();
        // put list of users in userNames
        // omit system users
        try {
            ResultSet rs = stmt.executeQuery("SELECT user FROM mysql.user");
            while (rs.next()){
                if (!rs.getString(1).equals("mysql.infoschema") &&
                        !rs.getString(1).equals("mysql.session") &&
                                !rs.getString(1).equals("mysql.sys"))
                                        userNames.add(rs.getString(1));
            }
        }
        catch (Exception e) {System.out.println("Exception");return null;}

        return userNames;
    }

    // returns a list of names of databases
    // TODO: it should only return the GC versions of db's,
    // TODO: so the admin knows what list to choose from when giving access to different users
    ArrayList<String> getDBNames () {
        File dataDir = new File (DB_DIR);
        ArrayList<String> dbNames = new ArrayList();

        for (File file : dataDir.listFiles()) {
            if (file.isDirectory() &&
                    !file.getName().equals("#innodb_temp") &&
                    !file.getName().equals("mysql") &&
                    !file.getName().equals("performance_schema") &&
                    !file.getName().equals("sys"))
            {
                dbNames.add(file.getName());
            }
        }
        return dbNames;
    }

    // returns a list of databases that the user has access to
    // TODO: needs to be changed from using folder structure to using prepended usernames
    ArrayList<String> showAccess (String user) {
        if (user.equals("current")) user = username;
        final String USER_DIR = USERS_DIR + "\\" + user;
        File userDir = new File (USER_DIR);
        ArrayList<String> names = new ArrayList();

        // if user does not exist then return an empty collection
        if (!userDir.isDirectory()) return names;

        for (File file : userDir.listFiles())
            if (file.isDirectory())
                names.add(file.getName());
        return names;
    }

    // creates a new user account
    // returns true if success
    boolean createUser (String user, String pass){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/admin", username, password);
            stmt.execute("CREATE USER \'" + user + "\' IDENTIFIED BY \'" + pass + "\'");
            stmt.execute("GRANT ALL PRIVILEGES ON Admin.* to \'" + user + "\'");
        }
        catch (Exception e) {System.out.println("exception");return false;}

        return true;
    }

    // deletes a user account by running SQL query
    // returns true if success
    // TODO: needs to delete all databases the user created
    boolean deleteUser (String user) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/admin", username, password);
            stmt.execute("DROP USER \'" + user + "\'");
        }
        catch (Exception e) {System.out.println("exception");return false;}

        return true;
    }

    // retrieves a database from MySQL Server and copies it to USERS_DIR\ userName\ dbName folder
    // returns true if success
    // TODO: needs to be changed from using folder structure to using prepended usernames
    // TODO: interpret error code mysqlbackup returns and return true/false
    // TODO: if user does not exist then return false
    boolean getGC (String userName, String dbName) {

        final String TARGET_DIR = USERS_DIR + "\\" + userName; // directory where GC is to be created
        // used for mysqlbackup command line options
        final String BACKUP_IMAGE = "--backup-image=" + TEMP_DIR + "\\backup.mbi";
        final String INCLUDE_TABLES = "--include-tables=\"" + dbName + "\"";
        final String BACKUP_TEMP_DIR = "--backup-dir=" + TEMP_DIR + "\\tempb";
        final String RESTORE_TEMP_DIR = "--backup-dir=" + TEMP_DIR + "\\tempr";
        final String DATA_DIR = "--datadir=" + TARGET_DIR;

        // used for command line
        // backupCommand will most likely have to use ssh to ask the production server to backup the server
        // using MEB and send it to USERS_DIR on this (golden) server
        String[] backupCommand = {"mysqlbackup", "--user=root", "--password=Root", BACKUP_TEMP_DIR,
                BACKUP_IMAGE, "--compress", INCLUDE_TABLES, "backup-to-image"};
        String[] restoreCommand = {"mysqlbackup", RESTORE_TEMP_DIR, DATA_DIR,
                "--uncompress", BACKUP_IMAGE, "copy-back-and-apply-log"};

        // run backup
        try {
            ProcessBuilder builder = new ProcessBuilder(backupCommand);
            builder.redirectErrorStream(true);
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        }
        catch (Exception E){return false;}

        // restore to target folder
        try {
            ProcessBuilder builder = new ProcessBuilder(restoreCommand);
            builder.redirectErrorStream(true);
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        }
        catch (Exception E) {return false;}

        // delete temporary files
        try {
            File folder = new File(TEMP_DIR);
            delete(folder);
        }
        catch (Exception E) {return false;}
        System.out.println("\nTemporary files deleted successfully.\n");

        // return
        return true;
    }

    // helper method
    // deletes the specified folder and all its contents
    private void delete(File folder) throws IOException {

        for (File childFile : folder.listFiles()) {

            if (childFile.isDirectory()) {
                delete(childFile);
            } else {
                if (!childFile.delete()) {
                    throw new IOException();
                }
            }
        }

        if (!folder.delete()) {
            throw new IOException();
        }
    }
}
