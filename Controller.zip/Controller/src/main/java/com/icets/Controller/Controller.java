package com.icets.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
public class Controller {

    @RequestMapping("/getDBNames")
    public ArrayList<String> getDBNames () {
        return GoldenAPI.getDBNames();
    }

    @RequestMapping("/getGC")
    public boolean getGC (@RequestParam("user") String user, @RequestParam("db") String db) {
        return GoldenAPI.getGC(user, db);
    }

    @RequestMapping("/createUser")
    public boolean createUser (@RequestParam("user") String user) {
        return GoldenAPI.createUser(user);
    }
}
